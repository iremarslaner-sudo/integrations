<?php

namespace DvBusiness\ApiClient\Response;


class GenerateCaptchaTokenResponseModel
{
    /** @var string|null  */
    private $keyToken = null;
    /** @var string|null  */
    private $captchaToken = null;

    public function __construct(array $responseData)
    {
        $this->captchaToken = $responseData['captcha_token'] ?? null;
        $this->keyToken     = $responseData['key_token'] ?? null;
    }

    /**
     * @return string|null
     */
    public function getKeyToken()
    {
        return $this->keyToken;
    }

    /**
     * @return string|null
     */
    public function getCaptchaToken()
    {
        return $this->captchaToken;
    }
}
