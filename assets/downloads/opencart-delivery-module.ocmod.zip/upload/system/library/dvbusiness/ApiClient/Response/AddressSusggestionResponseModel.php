<?php

namespace DvBusiness\ApiClient\Response;

class AddressSusggestionResponseModel
{
    /** @var string */
    private $formattedAddress;

    /** @var string|null */
    private $streetLevelAddress;

    /** @var string|null  */
    private $cityLevelAddress;

    public function __construct(array $responseData)
    {
        $this->formattedAddress   = $responseData['formatted_address'];
        $this->streetLevelAddress = $responseData['street_level_address'] ?? null;
        $this->cityLevelAddress   = $responseData['city_level_address'] ?? null;
    }

    public function getFormatedAddress(): string
    {
        return $this->formattedAddress;
    }

    /**
     * @return string|null
     */
    public function getStreetLevelAddress()
    {
        return $this->streetLevelAddress;
    }

    /**
     * @return string|null
     */
    public function getCityLevelAddress()
    {
        return $this->cityLevelAddress;
    }
}
