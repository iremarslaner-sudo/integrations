<?php

namespace DvBusiness\Utils;

class GeoDistance
{
    public static function getDistanceInMeters(float $lat1, float $lon1, float $lat2, float $lon2) {
        $pi80 = M_PI / 180;
        $lat1 *= $pi80;
        $lon1 *= $pi80;
        $lat2 *= $pi80;
        $lon2 *= $pi80;

        $earthRadius = 6372797.0; // mean radius of Earth in m

        $dlat = $lat2 - $lat1;
        $dlon = $lon2 - $lon1;
        $a    = sin($dlat / 2) * sin($dlat / 2) + cos($lat1) * cos($lat2) * sin($dlon / 2) * sin($dlon / 2);
        $c    = 2 * atan2(sqrt($a), sqrt(1 - $a));
        $m    = $earthRadius * $c;

        return $m;
    }
}
