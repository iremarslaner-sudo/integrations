<?php

namespace DvBusiness;

use DvBusiness\ApiClient\DvCmsModuleApiClient;
use DvBusiness\GeneralCache\Cache;
use DvBusiness\GeoCoder\GeoCoderService;
use DvBusiness\GeoCoder\GeoSuggestion\GeoSuggestionService;
use DvBusiness\GeoCoder\Providers\DadataGeoCoderClient;
use DvBusiness\GeoCoder\Providers\DostavistaGeoCoderClient;
use DvBusiness\GeoCoder\Providers\GeoProvidersEnum;
use DvBusiness\Http\HttpClient;
use DvBusiness\ModuleConfig\ModuleConfig;
use ModelSettingSetting;

class DvServiceLocator
{
    /** @var self */
    private static $_instance;

    /** @var DvOptions */
    private $dvOptions;

    /** @var GeoCoderService|null */
    private $geoCoderService = null;

    /** @var DadataGeoCoderClient|null */
    private $dadataGeoCoderClient = null;

    /** @var DostavistaGeoCoderClient|null */
    private $dostavistaGeoCoderClient = null;

    /** @var GeoSuggestionService|null */
    private $geoSuggestionService = null;

    /** @var null|DvCmsModuleApiClient */
    private $dvCmsModuleApiClient = null;

    /**
     * @param ModelSettingSetting $settingsModel
     */
    private function __construct($settingsModel)
    {
        $this->dvOptions = new DvOptions($settingsModel);
    }

    /**
     * @param ModelSettingSetting|null $settingsModel
     */
    public static function getInstance($settingsModel = null): self
    {
        if (self::$_instance === null) {
            self::$_instance = new self($settingsModel);
        }

        return self::$_instance;
    }

    private function __clone()
    {
    }

    private function __wakeup()
    {
    }

    public function getGeoCoderService(): GeoCoderService
    {
        if ($this->geoCoderService) {
            return $this->geoCoderService;
        }

        $cache  = new Cache(86400);
        $config = new ModuleConfig();

        $geoCoderProvider = null;

        switch ($config->getGeoCoderProviderName()) {
            case GeoProvidersEnum::PROVIDER_DOSTAVISTA:
                $geoCoderProvider = $this->getDostavistaGeoCoderClient();
                break;
            case GeoProvidersEnum::PROVIDER_DADATA:
                $geoCoderProvider = $this->getDadataGeoCoderClient();
                break;
        }

        $this->geoCoderService = new GeoCoderService($geoCoderProvider, $cache);

        return $this->geoCoderService;
    }

    /**
     * @return DadataGeoCoderClient|null
     */
    public function getDadataGeoCoderClient()
    {
        if ($this->dadataGeoCoderClient) {
            return $this->dadataGeoCoderClient;
        }

        $httpClient = new HttpClient();
        $config     = new ModuleConfig();

        $this->dadataGeoCoderClient = $config->getDadataToken()
            ? new DadataGeoCoderClient($httpClient, $config->getDadataToken())
            : null;

        return $this->dadataGeoCoderClient;
    }

    /**
     * @return DostavistaGeoCoderClient|null
     */
    public function getDostavistaGeoCoderClient()
    {
        if ($this->dostavistaGeoCoderClient) {
            return $this->dostavistaGeoCoderClient;
        }

        $dvCmsModuleApiClient = $this->getDvCmsModuleApiClient();

        $this->dostavistaGeoCoderClient = new DostavistaGeoCoderClient($dvCmsModuleApiClient);

        return $this->dostavistaGeoCoderClient;
    }

    /**
     * @return DvCmsModuleApiClient|null
     */
    public function getDvCmsModuleApiClient()
    {
        if ($this->dvCmsModuleApiClient) {
            return $this->dvCmsModuleApiClient;
        }

        $this->dvCmsModuleApiClient = new DvCmsModuleApiClient(
            $this->dvOptions->getApiUrl(), $this->dvOptions->getAuthToken()
        );

        return $this->dvCmsModuleApiClient;
    }

    /**
     * @return GeoSuggestionService|null
     */
    public function getGeoSuggestionService()
    {
        if ($this->geoSuggestionService) {
            return $this->geoSuggestionService;
        }

        $cache = new Cache(86400);

        $this->geoSuggestionService = new GeoSuggestionService(
            $this->getDostavistaGeoCoderClient(),
            $cache
        );

        return $this->geoSuggestionService;
    }
}
