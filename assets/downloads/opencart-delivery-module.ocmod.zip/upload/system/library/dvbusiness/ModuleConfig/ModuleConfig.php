<?php

namespace DvBusiness\ModuleConfig;

use DvBusiness\GeoCoder\Providers\GeoProvidersEnum;

class ModuleConfig
{
    /** @var array */
    private $data;

    public function __construct()
    {
        $configData = include (__DIR__ . '/module_config.php');
        $this->data = is_array($configData) ? $configData : [];
    }

    public function getDvCmsModuleApiProdUrl(): string
    {
        return $this->data['dv_cms_module_api_prod_url'];
    }

    public function getDvCmsModuleApiTestUrl(): string
    {
        return $this->data['dv_cms_module_api_test_url'];
    }

    public function getCountry(): string
    {
        return $this->data['country'] ?? 'ru';
    }

    public function getDadataToken(): string
    {
        return $this->data['dadata_token'] ?? '';
    }

    public function isUseAddressSuggestions(): bool
    {
        return $this->data['is_use_address_suggestions'] ?? true;
    }

    /**
     * @return string|null
     */
    public function getGeoCoderProviderName()
    {
        return  $this->data['geo_coder_provider'] ?? GeoProvidersEnum::PROVIDER_DOSTAVISTA;
    }

    public function isMotoboxRequiredOptionUsed(): bool
    {
        return $this->data['is_motobox_required_option_used'] ?? false;
    }

    public function isAuthCaptchaRequired(): bool
    {
        return $this->data['is_auth_captcha_required'] ?? true;
    }

    public function getAvailableVehicleTypes(): array
    {
        return $this->data['available_vehicle_types'];
    }
}
