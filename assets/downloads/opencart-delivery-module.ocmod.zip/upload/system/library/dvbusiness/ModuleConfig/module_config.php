<?php

return [
    'country'                    => 'tr',
    'dv_cms_module_api_prod_url' => 'https://robot.banabikurye.com/api/cms-module',
    'dv_cms_module_api_test_url' => 'https://robotapitest.banabikurye.com/api/cms-module',

    // Доступна ли опция МОТОБОКС ТРЕБУЕТСЯ
    'is_motobox_required_option_used' => false,
    // Требуется капча для авторизации
    'is_auth_captcha_required' => true,

    'available_vehicle_types' => [8, 7],
];
