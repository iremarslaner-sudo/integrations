<?php

namespace DvBusiness\Http;

class HttpClientException extends \Exception
{

}
