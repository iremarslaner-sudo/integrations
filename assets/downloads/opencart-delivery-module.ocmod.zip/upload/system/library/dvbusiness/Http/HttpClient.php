<?php

namespace DvBusiness\Http;

class HttpClient
{
    public function sendRequest(HttpRequest $request): HttpResponse
    {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $request->getUri());
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $request->getMethod());
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

        $headers = [];
        foreach ($request->getHeaders() as $key => $value) {
            $headers[] = "{$key}: {$value}";
        }

        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 15);
        curl_setopt($curl, CURLOPT_TIMEOUT, 20);

        if (in_array($request->getMethod(), ['POST', 'PUT', 'DELETE'])) {
            curl_setopt($curl, CURLOPT_POSTFIELDS, $request->getBody());
        }

        $headers = [];

        curl_setopt($curl, CURLOPT_HEADERFUNCTION,
            function($curl, $header) use (&$headers)
            {
                $len = strlen($header);
                $header = explode(':', $header, 2);
                if (count($header) < 2)
                    return $len;

                $headers[strtolower(trim($header[0]))][] = trim($header[1]);

                return $len;
            }
        );

        $result   = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        $curlErrorMassage = curl_error($curl);
        $curlErrorNumber  = curl_errno($curl);

        curl_close($curl);

        if ($result === false) {
            throw new HttpClientException($curlErrorMassage, $curlErrorNumber);
        }

        return new HttpResponse($httpCode, $headers, $result);
    }
}
