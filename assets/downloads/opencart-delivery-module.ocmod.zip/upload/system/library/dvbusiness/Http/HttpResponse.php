<?php

namespace DvBusiness\Http;

class HttpResponse
{
    /** @var int */
    private $statusCode;

    /** @var string|null */
    private $body;

    /** @var string[] */
    private $headers;


    public function __construct(int $statusCode, array $headers = [], string $body = null)
    {
        $this->statusCode = $statusCode;
        $this->headers    = $headers;
        $this->body       = $body;
    }

    public function getStatusCode(): int
    {
        return $this->statusCode;
    }

    public function getBody(): string
    {
        return $this->body;
    }

    public function getHeaders(): array
    {
        return $this->headers;
    }
}
