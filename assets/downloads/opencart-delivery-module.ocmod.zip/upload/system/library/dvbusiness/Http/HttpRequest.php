<?php

namespace DvBusiness\Http;

class HttpRequest
{
    const HTTP_METHOD_POST = 'POST';
    const HTTP_METHOD_GET  = 'GET';

    /** @var string */
    private $httpMethod;

    /** @var string $url */
    private $url;

    /** @var array $headers */
    private $headers;

    /** @var string|null $body */
    private $body;

    public function __construct(string $httpMethod, string $url, array $headers = [], string $body = null)
    {
        $this->httpMethod = $httpMethod;
        $this->url        = $url;
        $this->headers    = $headers;
        $this->body       = $body;
    }

    public function getUri(): string
    {
        return $this->url;
    }

    public function getMethod(): string
    {
        return $this->httpMethod;
    }

    public function getHeaders(): array
    {
        return $this->headers;
    }

    /**
     * @return string|null
     */
    public function getBody()
    {
        return $this->body;
    }
}
