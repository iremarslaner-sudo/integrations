<?php

namespace DvBusiness\OpenCart;

use DB;

class GeoZoneManager
{
    /** @var DB */
    private $db;

    /**
     * @param DB $db
     */
    public function __construct($db)
    {
        $this->db = $db;
    }

    /**
     * @param int $zoneId
     * @return GeoZone[]
     */
    public function getGeoZonesByZoneId(int $zoneId)
    {
        $result = $this->db->query('SELECT * FROM oc_zone WHERE zone_id = ' . (int) $zoneId);

        $zone = $result->rows ? $result->rows[0] : null;

        if (!$zone) {
            return [];
        }

        $result = $this->db->query(
            '
                SELECT DISTINCT oc_geo_zone.*
                FROM oc_zone_to_geo_zone 
                INNER JOIN oc_geo_zone ON oc_zone_to_geo_zone.geo_zone_id = oc_geo_zone.geo_zone_id
                WHERE (oc_zone_to_geo_zone.zone_id = ' . (int) $zoneId . ')
                OR (!oc_zone_to_geo_zone.zone_id AND oc_zone_to_geo_zone.country_id = ' . (int) $zone["country_id"] . ')
            '
        );

        $geoZones = [];
        foreach ($result->rows as $item) {
            $geoZones[] = new GeoZone($item);
        }

        return $geoZones;
    }
}
