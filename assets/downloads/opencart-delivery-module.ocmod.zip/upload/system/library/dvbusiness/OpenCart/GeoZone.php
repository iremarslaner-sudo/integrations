<?php


namespace DvBusiness\OpenCart;

class GeoZone
{
    /** @var int */
    private $geoZoneId;

    /** @var string */
    private $name;

    /** @var string */
    private $description;

    /** @var string */
    private $dateAdded;


    public function __construct($opencartGeoZoneModel)
    {
        $this->geoZoneId = $opencartGeoZoneModel['geo_zone_id'];
        $this->name      = $opencartGeoZoneModel['name'];
        $this->dateAdded = $opencartGeoZoneModel['date_added'];
    }

    public function getGeoZoneId(): int
    {
        return $this->geoZoneId;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getDescription(): string
    {
        return $this->description ?? '';
    }

    public function geDateAdded(): string
    {
        return $this->dateAdded;
    }
}
