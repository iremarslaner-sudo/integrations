<?php

namespace DvBusiness\GeoCoder\GeoSuggestion;

interface GeoSuggessionInterface
{
    /**
     * @param string $address
     * @return GeoSuggestionAddress[]
     */
    public function getSuggestionsByAddress(string $address): array;
}
