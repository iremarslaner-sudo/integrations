<?php

namespace DvBusiness\GeoCoder\GeoSuggestion;

class GeoSuggestionAddress
{
    /** @var string  */
    private $address;

    /** @var string|null  */
    private $city;

    /** @var string|null  */
    private $street;

    public function __construct(string $address, string $city = null, string $street = null)
    {
        $this->address = $address;
        $this->city    = $city;
        $this->street  = $street;
    }

    public function getAddress(): string
    {
        return $this->address;
    }

    /**
     * @return string|null
     */
    public function getCity()
    {
        return $this->city;
    }

    /**
     * @return string|null
     */
    public function getStreet()
    {
        return $this->street;
    }
}
