<?php

namespace DvBusiness\GeoCoder;

interface GeoCoderInterface
{
    /**
     * @param string $address
     * @return GeoPoint|null
     *
     * @throws GeoCoderHttpException
     */
    public function getGeoPointByAddress(string $address);
}
