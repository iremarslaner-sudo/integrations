<?php

namespace DvBusiness\GeoCoder\Providers;

use DvBusiness\GeoCoder\GeoCoderHttpException;
use DvBusiness\GeoCoder\GeoCoderInterface;
use DvBusiness\GeoCoder\GeoPoint;
use DvBusiness\GeoCoder\GeoSuggestion\GeoSuggessionInterface;
use DvBusiness\Http\HttpClient;
use DvBusiness\Http\HttpClientException;
use DvBusiness\Http\HttpRequest;

class DadataGeoCoderClient implements GeoCoderInterface, GeoSuggessionInterface
{
    /** @var string  */
    private $token;

    /** @var HttpClient */
    private $httpClient;

    public function __construct(HttpClient $httpClient,string $token)
    {
        $this->token      = $token;
        $this->httpClient = $httpClient;
    }

    /**
     * @return GeoPoint[]
     * @throws GeoCoderHttpException
     */
    private function sendRequest(string $address, int $count = null): array
    {
        $url = 'https://suggestions.dadata.ru/suggestions/api/4_1/rs/suggest/address';

        $headers = [
            'Content-Type'  => 'application/json',
            'Accept'        => 'application/json',
            'Authorization' => 'Token ' . $this->token,
        ];

        $body = [
            'query' => $address,
        ];

        if ($count) {
            $body['count'] = $count;
        }

        $body = json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        $httpRequest = new HttpRequest('POST', $url, $headers, $body);

        $geoPoints = [];
        try {
            $httpResponse = $this->httpClient->sendRequest($httpRequest);
            $result = $httpResponse->getBody();

            if ($httpResponse->getStatusCode() !== 200) {
                throw new GeoCoderHttpException($httpResponse->getBody());
            }

            $json = json_decode($result, true);

            $suggestions = $json['suggestions'] ?? null;
            if (!$suggestions) {
                return [];
            }

            foreach ($suggestions as $suggestion) {
                $cityName = $suggestion['data']['city'] ?: $suggestion['data']['settlement'];
                $geoPoints[] = (new GeoPoint($address, $suggestion['value'], (float) $suggestion['data']['geo_lat'], (float) $suggestion['data']['geo_lon']))
                    ->setStreet($suggestion['data']['street'] ?? null)
                    ->setBuildingNumber($suggestion['data']['house'] ?? null)
                    ->setFlatNumber($suggestion['data']['flat'] ?? null)
                    ->setRegionKladrId($suggestion['data']['region_kladr_id'] ?? null)
                    ->setCityKladrId($suggestion['data']['city_kladr_id'] ?? null)
                    ->setTimeZone($suggestion['data']['timezone'] ?? null)
                    ->setCityName($cityName)
                ;
            }

        } catch (HttpClientException $httpClientException) {
            throw new GeoCoderHttpException(
                $httpClientException->getMessage(), $httpClientException->getCode(), $httpClientException
            );
        }

        return $geoPoints;
    }

    /**
     * @return GeoPoint|null
     * @throws GeoCoderHttpException
     */
    public function getGeoPointByAddress(string $address)
    {
        $geoPoints = $this->sendRequest($address, 1);
        return $geoPoints[0] ?? null;
    }

    /**
     * @return GeoPoint[]
     */
    public function getSuggestionsByAddress(string $address): array
    {
        return $this->sendRequest($address);
    }
}
