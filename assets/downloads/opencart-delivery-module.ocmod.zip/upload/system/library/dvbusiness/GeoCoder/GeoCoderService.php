<?php

namespace DvBusiness\GeoCoder;

use DvBusiness\GeneralCache\CacheItem;
use DvBusiness\GeneralCache\Cache;

class GeoCoderService
{
    /** @var GeoCoderInterface */
    private $geoCoderProvider;

    /** @var Cache  */
    private $cache;

    public function __construct(GeoCoderInterface $geoCoder, Cache $cache)
    {
        $this->geoCoderProvider = $geoCoder;
        $this->cache            = $cache;
    }

    public function getAddressCacheKey(string $address): string
    {
        return 'geocoder:' . md5($address);
    }

    /**
     * @return GeoPoint|null
     */
    public function getGeoPointByAddress(string $address)
    {
        $address = trim($address);
        if (!$address) {
            return null;
        }

        $geoPoint = $this->getGeoPointFromCache($address);
        if ($geoPoint) {
            return $geoPoint;
        }

        if (!$this->geoCoderProvider) {
            return null;
        }

        $geoPoint = $this->geoCoderProvider->getGeoPointByAddress($address);
        if ($geoPoint) {
            $this->setGeoPointInCache($geoPoint);
            return $geoPoint;
        }

        return null;
    }

    private function setGeoPointInCache(GeoPoint $geoPoint)
    {
        // Закешируем точки
        $this->cache->save(new CacheItem(
            $this->getAddressCacheKey($geoPoint->getOriginAddress()),
            $this->getJsonFromGeoPoint($geoPoint),
            604800
        ));
    }

    /**
     * @param string $address
     * @return GeoPoint|null
     */
    private function getGeoPointFromCache(string $address)
    {
        $key  = $this->getAddressCacheKey($address);

        if ($this->cache->hasItem($key)) {
            return $this->getGeoPointFromCacheJson($this->cache->getItem($key)->get());
        }

        return null;
    }

    private function getGeoPointFromCacheJson(string $json): GeoPoint
    {
        $data = json_decode($json, true);
        return (new GeoPoint($data['origin_address'], $data['formatted_address'], (float) $data['latitude'], (float) $data['longitude']))
            ->setStreet($data['street'] ?? null)
            ->setBuildingNumber($data['building_number'] ?? null)
            ->setFlatNumber($data['flat_number'] ?? null)
            ->setRegionKladrId($data['region_kladr_id'] ?? null)
            ->setCityKladrId($data['city_kladr_id'] ?? null)
            ->setTimeZone($data['time_zone'] ?? null)
            ->setCityName($data['city_name'])
            ;
    }

    private function getJsonFromGeoPoint(GeoPoint $geoPoint): string
    {
        $data = [
            'origin_address'    => $geoPoint->getOriginAddress(),
            'formatted_address' => $geoPoint->getFormattedAddress(),
            'latitude'          => $geoPoint->getLatitude(),
            'longitude'         => $geoPoint->getLongitude(),
            'street'            => $geoPoint->getStreet(),
            'building_number'   => $geoPoint->getBuildingNumber(),
            'flat_number'       => $geoPoint->getFlatNumber(),
            'region_kladr_id'   => $geoPoint->getRegionKladrId(),
            'city_kladr_id'     => $geoPoint->getCityKladrId(),
            'time_zone'         => $geoPoint->getTimeZone(),
            'city_name'         => $geoPoint->getCityName(),
        ];

        return json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
}
