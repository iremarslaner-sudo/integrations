<?php

namespace DvBusiness\GeoCoder\Providers;

use DvBusiness\ApiClient\DvCmsModuleApiClient;
use DvBusiness\ApiClient\DvCmsModuleApiHttpException;
use DvBusiness\GeoCoder\GeoCoderHttpException;
use DvBusiness\GeoCoder\GeoCoderInterface;
use DvBusiness\GeoCoder\GeoPoint;
use DvBusiness\GeoCoder\GeoSuggestion\GeoSuggessionInterface;
use DvBusiness\GeoCoder\GeoSuggestion\GeoSuggestionAddress;
use DvBusiness\Http\HttpClientException;

class DostavistaGeoCoderClient implements GeoSuggessionInterface, GeoCoderInterface
{
    /** @var DvCmsModuleApiClient  */
    private $dvApiClient;

    public function __construct(DvCmsModuleApiClient $dvApiClient)
    {
        $this->dvApiClient = $dvApiClient;
    }

    /**
     * @return GeoSuggestionAddress[]
     */
    public function getSuggestionsByAddress(string $address): array
    {
        $dostavistaAddressSuggestionsResponseModels = [];

        try {
            $dostavistaAddressSuggestionsResponseModels = $this->dvApiClient->getGeoSuggestions($address);
        } catch (\Exception $httpClientException) {
            throw new GeoCoderHttpException(
                $httpClientException->getMessage(), $httpClientException->getCode(), $httpClientException
            );
        }

        $points = [];
        foreach ($dostavistaAddressSuggestionsResponseModels as $addressSuggestionsResponseModel) {
            $points[] = new GeoSuggestionAddress(
                $addressSuggestionsResponseModel->getFormatedAddress(),
                $addressSuggestionsResponseModel->getCityLevelAddress(),
                $addressSuggestionsResponseModel->getStreetLevelAddress()
            );
        }

        return $points;
    }

    /**
     * @return GeoPoint|null
     */
    public function getGeoPointByAddress(string $address)
    {
        $geoPoint = null;

        try {
            $geoPoint = $this->dvApiClient->geocode(trim($address));
        } catch (DvCmsModuleApiHttpException $exception) {

        }

        return $geoPoint;
    }
}
