<?php

namespace DvBusiness\GeoCoder\GeoSuggestion;

use DvBusiness\GeneralCache\CacheItem;
use DvBusiness\GeneralCache\Cache;

class GeoSuggestionService
{
    /** @var GeoSuggessionInterface */
    private $geoSuggestor;

    /** @var Cache  */
    private $cache;

    public function __construct(GeoSuggessionInterface $geoSuggestor, Cache $cache)
    {
        $this->geoSuggestor = $geoSuggestor;
        $this->cache        = $cache;
    }

    public function getAddressCacheKey(string $address): string
    {
        return 'geosuggests:' . md5($address);
    }

    /**
     * @return GeoSuggestionAddress[]
     */
    public function getSuggestionAddressesByAddress(string $address): array
    {
        $address = trim($address);
        if (!$address) {
            return [];
        }

        $geoSuggestionAddresses = $this->getGeoSuggestionsFromCache($address);
        if ($geoSuggestionAddresses) {
            return $geoSuggestionAddresses;
        }

        $geoSuggestionAddresses = $this->geoSuggestor->getSuggestionsByAddress($address);
        if ($geoSuggestionAddresses) {
            $this->setGeoSuggestionAddressesInCache($address, $geoSuggestionAddresses);
            return $geoSuggestionAddresses;
        }

        return [];
    }

    private function getGeoSuggestionsFromCache(string $address): array
    {
        $cacheKey = $this->getAddressCacheKey($address);

        return $this->cache->hasItem($cacheKey)
            ? $this->getGeoSuggestionAddressesFromCacheJson($this->cache->getItem($cacheKey)->get())
            : [];
    }

    private function getGeoSuggestionAddressesFromCacheJson(string $json): array
    {
        $data = json_decode($json, true);
        $suggestionAddreses = [];

        foreach ($data as $pointData) {
            $suggestionAddreses[] = new GeoSuggestionAddress(
                $pointData['address'],
                $pointData['city'],
                $pointData['street']
            );
        }

        return $suggestionAddreses;
    }

    /**
     * @param GeoSuggestionAddress[] $suggestionAddresses
     */
    private function setGeoSuggestionAddressesInCache(string $originAddress, array $suggestionAddresses)
    {
        // Закешируем точки
        $this->cache->save(new CacheItem(
            $this->getAddressCacheKey($originAddress),
            $this->getJsonFromGeoSuggestionAddresses($suggestionAddresses),
            604800
        ));
    }

    /**
     * @param GeoSuggestionAddress[] $suggestionAddresses
     */
    private function getJsonFromGeoSuggestionAddresses(array $suggestionAddresses): string
    {
        $data = [];

        foreach ($suggestionAddresses as $suggestionAddress) {
            $data[] = [
                'address' => $suggestionAddress->getAddress(),
                'city'    => $suggestionAddress->getCity(),
                'street'  => $suggestionAddress->getStreet(),
            ];
        }

        return json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
}
