<?php

namespace DvBusiness\GeoCoder\Providers;

class GeoProvidersEnum
{
    const PROVIDER_DADATA     = 'dadata';
    const PROVIDER_DOSTAVISTA = 'dostavista';
}
