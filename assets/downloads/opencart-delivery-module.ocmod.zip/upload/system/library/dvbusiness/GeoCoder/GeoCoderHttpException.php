<?php

namespace DvBusiness\GeoCoder;

use Exception;

class GeoCoderHttpException extends Exception
{
    /** @var string  */
    private $responseBody = '';

    /** @var string  */
    private $httpCode = '';

    public function setResponseBody(string $responseBody): GeoCoderHttpException
    {
        $this->responseBody = $responseBody;
        return $this;
    }

    public function getResponseBody(): string
    {
        return $this->responseBody;
    }

    public function setHttpCode(string $httpCode): GeoCoderHttpException
    {
        $this->httpCode = $httpCode;
        return $this;
    }

    public function getHttpCode(): string
    {
        return $this->httpCode;
    }
}
