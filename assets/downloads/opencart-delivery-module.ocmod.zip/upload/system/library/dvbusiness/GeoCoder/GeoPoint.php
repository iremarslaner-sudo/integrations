<?php

namespace DvBusiness\GeoCoder;

class GeoPoint
{
    /** @var string */
    private $originAddress;

    /** @var string */
    private $formattedAddress;

    /** @var float */
    private $latitude;

    /** @var float */
    private $longitude;

    /** @var string|null */
    private $street;

    /** @var string|null */
    private $buildingNumber;

    /** @var string|null */
    private $flatNumber;

    /** @var string|null */
    private $regionKladrId = null;

    /** @var string|null */
    private $cityKladrId = null;

    /** @var string|null  */
    private $cityName = null;

    /** @var string|null  */
    private $timeZone = null;

    public function __construct(string $originAddress, $formattedAddress, float $latitude, float $longitude)
    {
        $this->originAddress    = $originAddress;
        $this->formattedAddress = $formattedAddress;
        $this->latitude         = $latitude;
        $this->longitude        = $longitude;
    }

    public function getOriginAddress(): string
    {
        return $this->originAddress;
    }

    public function getFormattedAddress(): string
    {
        return $this->formattedAddress;
    }

    public function getLatitude(): float
    {
        return $this->latitude;
    }

    public function getLongitude(): float
    {
        return $this->longitude;
    }

    public function setStreet(string $street = null): self
    {
        $this->street = $street;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getStreet()
    {
        return $this->street;
    }

    public function setBuildingNumber(string $buildingNumber = null): self
    {
        $this->buildingNumber = $buildingNumber;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getBuildingNumber()
    {
        return $this->buildingNumber;
    }

    public function setFlatNumber(string $flatNumber = null): self
    {
        $this->flatNumber = $flatNumber;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getFlatNumber()
    {
        return $this->flatNumber;
    }

    public function setRegionKladrId(string $regionKladrId = null): self
    {
        $this->regionKladrId = $regionKladrId;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getRegionKladrId()
    {
        return $this->regionKladrId;
    }

    public function setCityKladrId(string $cityKladrId = null): self
    {
        $this->cityKladrId = $cityKladrId;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getCityKladrId()
    {
        return $this->cityKladrId;
    }

    public function setTimeZone(string $timeZone = null): self
    {
        $this->timeZone = $timeZone;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getTimeZone()
    {
        return $this->timeZone;
    }

    public function setCityName(string $city = null): self
    {
        $this->cityName = $city;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getCityName()
    {
        return $this->cityName;
    }
}
