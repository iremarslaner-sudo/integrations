<?php

$_['text_title'] = 'Banabikurye';
$_['text_general_delivery'] = 'Aynı Gün Teslimat - Banabikurye';
$_['text_delivery_calculation_error'] = 'Teslimat hesaplanamadı';
$_['text_currency_rub'] = 'TR';
$_['text_free_delivery'] = 'Ücretsiz teslimat';
$_['text_shipping_datetime'] = 'Teslimat zamanı';
$_['text_time_from'] = '';
$_['text_time_to'] = '-';
$_['text_today'] = 'bugün';
$_['text_tomorrow'] = 'yarın';
$_['text_nearest_date'] = 'Erken teslimat';
$_['error_address_empty'] = 'Could not calculate cost, please fill the address of delivery';
$_['error_invalid_region'] = 'Delivery in this city is not possible';
$_['error_different_regions'] = 'Delivery in this city is not possible';
$_['text_calculation_result_cost'] = '{cost} {currency}';
