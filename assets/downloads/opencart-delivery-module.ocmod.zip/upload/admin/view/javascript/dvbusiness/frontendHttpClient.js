if (typeof(dvbusiness) === 'undefined') {
    var dvbusiness = {};
}

/**
 * Объект "Frontend Http Client"
 * @type {dvbusiness.frontendHttpClient}
 *
 * Интерфейс колбеков ответа:
 * responseCallback(success, error, parameterErrors, rawResponse);
 *
 */
dvbusiness.frontendHttpClient = new (function() {
    /** @type {dvbusiness.frontendHttpClient} */
    var _self = this;

    function getJsonFromLocation() {
        url = location.search;

        var query = url.substr(1);
        var result = {};
        query.split("&").forEach(function (part) {
            var item = part.split("=");
            result[item[0]] = decodeURIComponent(item[1]);
        });

        return result;
    }

    function sendRequest(method, route, postData, responseCallback) {
        var handler = function(response, textStatus, jqXHR) {
            var parameterErrors = null;
            var error = null;
            var isSuccessful = true;
            var responseJson = typeof(response.responseJSON) !== 'undefined' ? response.responseJSON : response;

            if (typeof(responseJson.error) !== 'undefined' || jqXHR.status != 200) {
                error = response.error;
                isSuccessful = false;
            }

            if (typeof(responseJson.parameter_errors) !== 'undefined') {
                parameterErrors = responseJson.parameter_errors;
            }

            if (responseCallback && typeof(responseCallback) !== 'undefined') {
                responseCallback(isSuccessful, error, parameterErrors, responseJson);
            }
        };

        var headers = {};

        var adminUri = new URL(window.location.href);
        adminUri.searchParams.set('route', route);

        if (method === 'POST') {
            $.ajax(
                {
                    type: 'POST',
                    url: adminUri.toString(),
                    data: JSON.stringify(postData),
                    dataType: 'json',
                    headers: headers
                }
            ).always(handler);
        } else {
            $.ajax({type: 'GET', url: adminUri.toString(), dataType: 'json', headers: headers}).always(handler);
        }
    }

    this.calculateOrder = function(data, responseCallback) {
        sendRequest('POST', 'extension/shipping/dvbusiness/orderFormCalculate', data, responseCallback);
    };

    this.createOrder = function(data, responseCallback) {
        sendRequest('POST', 'extension/shipping/dvbusiness/orderFormCreate', data, responseCallback);
    };

    this.saveWarehouse = function(data, responseCallback) {
        sendRequest('POST', 'extension/shipping/dvbusiness/warehouseFormSave', data, responseCallback);
    };

    this.deleteWarehouse = function(data, responseCallback) {
        sendRequest('POST', 'extension/shipping/dvbusiness/warehouseDelete', data, responseCallback);
    };

    this.createAuthToken = function(data, responseCallback) {
        sendRequest('POST', 'extension/shipping/dvbusiness/createAuthToken', data, responseCallback);
    };

    this.storeSettings = function(data, responseCallback) {
        sendRequest('POST', 'extension/shipping/dvbusiness/storeSettings', data, responseCallback);
    };

    this.getPaymentMethods = function(data, responseCallback) {
        sendRequest('POST', 'extension/shipping/dvbusiness/getPaymentMethods', data, responseCallback);
    };

    this.setLastFinishedWizardStep = function(data, responseCallback) {
        sendRequest('POST', 'extension/shipping/dvbusiness/setWizardLastFinishedStep', data, responseCallback);
    };

    this.dostavistaClientLogout = function(responseCallback) {
        sendRequest('POST', 'extension/shipping/dvbusiness/dostavistaLogout', {}, responseCallback);
    };

    this.getAddressSuggestions = function(query, responseCallback) {
        sendRequest('POST', 'extension/shipping/dvbusiness/getAddressSuggestions', {query : query}, responseCallback);
    };

    // Ближайший адрес
    this.getNearestWarehouse = function(address, responseCallback) {
        sendRequest('POST', 'extension/shipping/dvbusiness/getNearestWarehouse', {address : address}, responseCallback);
    };

    // Получения токена для капчи
    this.generateCaptchaToken = function(data, responseCallback) {
        sendRequest('POST', 'extension/shipping/dvbusiness/generateCaptchaToken', data, responseCallback);
    };
});

