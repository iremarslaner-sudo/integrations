if (typeof(dvbusiness) === 'undefined') {
    var dvbusiness = {};
}

if (typeof(dvbusiness.form) === 'undefined') {
    dvbusiness.form = {};
}

var $ = jQuery;

/**
 * Конструктор для создания поля Адрес
 *
 * @requires jQuery, jQueryUI.autocomplete
 *
 * @param {object} input Элемент ввода адреса
 * @param {object} container Контейнер
 * @return {dvbusiness.form.address}
 */
dvbusiness.form.address = function(input, container) {
    var _self = this;
    var _inputUiElement = $(input);

    /**
     * Слушатели события Change
     * @type Array
     */
    var _listenersChange = [];

    /**
     * Возвращает поле ввода адреса
     * @returns {object}
     */
    this.getInputElement = function() {
        return _inputUiElement;
    };

    /**
     * Инициализирует поле ввода адреса, устанавливает необходимые события
     * Запускается конструктором
     *
     * @returns {undefined}
     */
    this.init = function() {
        if (!container) {
            container = 'body';
        }
        _inputUiElement.prop('autocomplete', 'off');
        _inputUiElement
            .bind('keydown', function(event) {
                if ( event.keyCode === $.ui.keyCode.TAB && $(this).autocomplete( "instance" ).menu.active) {
                    event.preventDefault();
                }
            })
            .bind('change', function(event) {
                if (!_inputUiElement.val()) {
                    _inputUiElement.val('');
                    _inputUiElement.data('address', '');
                    _inputUiElement.data('city', '');
                }
            })
            .autocomplete({
                minLength: 2,
                delay: 600,
                appendTo: container,
                source: function( request, response ) {
                    _inputUiElement.addClass('async-loader');
                    _self.getSuggestions(request, function(suggestions) {
                        _inputUiElement.removeClass('async-loader');
                        response(suggestions);
                    });
                },
                focus: function() {
                    // prevent value inserted on focus
                    return false;
                },
                select: function(event, ui) {
                    _inputUiElement.data('address', ui.item.address);
                    _inputUiElement.data('city', ui.item.city);
                    _inputUiElement.val(ui.item.address);

                    // Оповестим всех слушателей
                    for (var i in _listenersChange) {
                        _listenersChange[i](ui.item);
                    }

                    return false;
                }
            }).autocomplete('instance')._renderItem = function(ul, item) {
                var value = String(item.address).replace(new RegExp(_inputUiElement.val(), 'i'), '<strong>' + _inputUiElement.val() + '</strong>');
                return $('<li></li>')
                    .append(value)
                    .appendTo(ul);
            };
    };

    /**
     * Функция, подгружающая список подсказок адреса
     *
     * @param {object} request
     * @param {function} callback
     * @returns {undefined}
     */
    this.getSuggestions = function(request, callback) {
        dvbusiness.frontendHttpClient.getAddressSuggestions(encodeURIComponent(request.term), function(success, error, parameterErrors, response) {
            callback(response.suggestions);
        });
    };

    /**
     * Добавляет обработчик события Change
     *
     * @param {type} callback Функция-обработчик
     * @returns {dvbusiness.form.address}
     */
    this.onChange = function(callback) {
        _listenersChange.push(callback);
        return this;
    };

    this.init();
};
