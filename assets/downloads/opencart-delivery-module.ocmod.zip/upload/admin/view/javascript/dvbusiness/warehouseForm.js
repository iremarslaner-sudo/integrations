if (typeof(dvbusiness) === 'undefined') {
    dvbusiness = {};
}

dvbusiness.warehouseForm = new (function () {
    this.translations = {
        saving_error: 'Не удалось сохранить склад. Проверьте правильность заполненных полей и попробуйте повторить позже.',
    }
});

$(function() {
    var warehouseForm = $('#dvbusiness-warehouse-form');

    function saveWarehouse() {
        if (!getInputElements().length) {
            return;
        }

        licode.preloader.on(warehouseForm);

        var data = {};
        getInputElements().each(function () {
            var jInput = $(this);
            var name = jInput.attr('name');
            if (typeof (name) !== 'undefined') {
                if (name !== 'workdays') {
                    data[name] = jInput.is(':checkbox') ? jInput.prop('checked') : jInput.val();
                } else {
                    data['workdays'] = typeof(data['workdays']) === 'undefined' ? [] : data['workdays'];
                    if (jInput.prop('checked')) {
                        data['workdays'].push(jInput.val());
                    }
                }
            }
        });

        dvbusiness.frontendHttpClient.saveWarehouse(data, function (success, error, parameterErrors, response) {
            if (!success || typeof (response.warehouse_id) === 'undefined' || !response.warehouse_id) {
                licode.preloader.off(warehouseForm);
                alert(dvbusiness.warehouseForm.translations.saving_error);
            } else {
                window.location.href =
                    '/admin/?route=' + encodeURIComponent(response.redirect_route)
                    + '&user_token=' + encodeURIComponent(response.user_token);
            }
        });
    };

    function getInputElements() {
        return warehouseForm.find(':input');
    }

    warehouseForm.find('.button-save-warehouse').click(function() {
        saveWarehouse();
    });

    var packageLoader = new dvbusiness.packagesLoader();
    packageLoader.onJqueryUiAutocompleteLoaded(function (isJqueryUiAutocompleteEnabled) {
        var addressInput = warehouseForm.find('input[name="address"]:first');
        if (addressInput.hasClass('address-suggests') && isJqueryUiAutocompleteEnabled) {
            warehouseForm.find('input[name="city"]:first').hide();
            var warehouseAddress = new dvbusiness.form.address(addressInput, addressInput.parent());
            // На изменение адреса город сохраняем отдельно
            warehouseAddress.onChange(function (data) {
                var selectedWarehouseCity = data.city;
                var selectedWarehouseStreet = data.street;

                warehouseForm.find('input[name="city"]:first').val(selectedWarehouseCity);

                if (!selectedWarehouseCity) {
                    alert(dvbusiness.warehouseForm.translations.address_suggestions_fail_city_required);
                }

                if (!selectedWarehouseStreet) {
                    alert(dvbusiness.warehouseForm.translations.address_suggestions_fail_street_required);
                }
            });
            addressInput.on('change', function (){
                var cityInput = warehouseForm.find('input[name="city"]:first');

                if (!cityInput.val()) {
                    cityInput.parents('.form-group:first').removeClass('hidden');
                    cityInput.show();
                } else {
                    cityInput.parents('.form-group:first').addClass('hidden');
                    cityInput.hide();
                }
            });
        } else {
            warehouseForm.find('input[name="city"]:first').show();
        }
    });
});
