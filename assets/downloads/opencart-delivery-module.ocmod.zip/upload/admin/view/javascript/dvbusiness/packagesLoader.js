if (typeof(dvbusiness) === 'undefined') {
    var dvbusiness = {};
}

if (typeof(dvbusiness.packagesLoader) === 'undefined') {
    dvbusiness.packagesLoader = {};
}

var $ = jQuery;

dvbusiness.packagesLoader = function () {
    var _self = this;

    /**
     * Доступность пакета Autocomplete
     * @type {boolean}
     */
    this.isJqueryUiAutocompleteEnabled = false;

    /**
     * Слушатели события загрузки пакета Autocomplete
     * @type {callback[]}
     * @private
     */
    var _listenersLoadJqueryUiAutocomplete = [];

    this.onJqueryUiAutocompleteLoaded = function(callback) {
        _listenersLoadJqueryUiAutocomplete.push(callback);
    };

    this.notifyListenersOnLoadJqueryUiAutocomplete = function () {
        // Пройдемся по слушателям, и оповестим их о загрузке пакетов
        for (var i in _listenersLoadJqueryUiAutocomplete) {
            _listenersLoadJqueryUiAutocomplete[i](_self.isJqueryUiAutocompleteEnabled);
        }
    }

    $(function() {
        _self.onDocumentLoaded();
    });

    this.onDocumentLoaded = function() {
        var jqueryUiAutocompleteScriptPath = 'view/javascript/dvbusiness/vendor/jquery-ui-autocomplete.js'
        // Подключаем Jquery UI Autocomplete
        if (!isJqueryUiLoaded()) {
            includeJs(jqueryUiAutocompleteScriptPath, function () {
                _self.isJqueryUiAutocompleteEnabled = true;
                // Оповестим слушателей
                _self.notifyListenersOnLoadJqueryUiAutocomplete();
            });
            return;
        } else {
            if (!isJqueryUiVersionConfirmed()) {
                console.log(getJqueryUiVersion() + ' jqueryUi version using. Required JqueryUi version > 1.11.*. Aborting...');
                return;
            }

            // Подключим только Autocomplete
            if (!isJqueryUiAutocompleteLoaded()) {
                includeJs(jqueryUiAutocompleteScriptPath, function () {
                    _self.isJqueryUiAutocompleteEnabled = true;
                    // Оповестим слушателей
                    _self.notifyListenersOnLoadJqueryUiAutocomplete();
                });
                return;
            } else {
                _self.isJqueryUiAutocompleteEnabled = true;
            }
        }

        // Оповестим слушателей
        _self.notifyListenersOnLoadJqueryUiAutocomplete();
    }
};

function isJqueryUiVersionConfirmed()
{
    var jqueryUiVersion = getJqueryUiVersion();
    var result = false;
    var suitableVersions = [
        '1.10.',
        '1.11.',
        '1.12.',
    ];

    $.each(suitableVersions, function (index, version) {
        if (jqueryUiVersion.indexOf(version) >= 0) {
            result = true;
        }
    });

    return result;
}

function includeJs(path, callback = null)
{
    if (!callback) {
        callback = function(){
            console.log(path + ' script loaded');
        }
    }
    $.getScript(path, callback);
}

function getJqueryUiVersion()
{
    return isJqueryUiLoaded() ? jQuery.ui.version : null;
}

function isJqueryUiLoaded()
{
    return (typeof jQuery.ui !== 'undefined');
}

function isJqueryUiAutocompleteLoaded()
{
    return isJqueryUiLoaded() && (typeof jQuery.ui.autocomplete !== 'undefined');
}
